import React from "react"

function MyInfo(){
    return(
      <div>
        <h1>Mak</h1>
        <p>Yoyo my name is Mak, but you can call me rock, cuz imma be rocking this code up and down the block</p>
        <ol>
          <li>Lyon, France</li>
          <li>Cheese fritters</li>
          <li>Carbonated drinks</li>
        </ol>
      </div>
    )
  };

  export default MyInfo;