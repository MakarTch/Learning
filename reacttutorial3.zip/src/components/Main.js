import React from "react";
import ReactDOM from "react-dom";

function Main(){
    return(
        <p>In the main</p>
    )
}

export default Main;