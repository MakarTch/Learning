import React from "react"
import ReactDOM from "react-dom";

function Footer(){
    return(
        <h3>This is my footer</h3>        
    )
}

export default Footer;