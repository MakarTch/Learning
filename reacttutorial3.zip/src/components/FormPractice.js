import React from "react"

class FormPractice extends React.Component {

    constructor() {
        super()
        this.state = {
            visibility:"hidden",
            firstName: "",
            lastName: "",
            age: null,
            gender: null,
            location: null,
            noMeat:null,
            noDairy:null,
            noFish:null
        }
        this.handleChange = this.handleChange.bind(this)
        this.handleSubmit = this.handleSubmit.bind(this)
    }

    handleChange(event) {
        const { name, value } = event.target
            this.setState({
            [name]: value
        })
        
    }
    handleSubmit() {
        this.setState({
            visibility:"visible"
        })
    }

    render() {
        return (
            <div>
                <h1>Enter your info sir</h1>
                <form >
                    <input type="text" placeholder="First Name" autoComplete="off" name="firstName" onChange={this.handleChange} />
                    <input type="text" placeholder="Last Name" autoComplete="off" name="lastName" onChange={this.handleChange} />
                    <input type="number" placeholder="Age" autoComplete="off" name="age" onChange={this.handleChange} /><br />

                    <input type="radio" name="gender" value="male" onChange={this.handleChange}></input>
                    <label for="male">Male</label><br />
                    <input type="radio" name="gender" value="female" onChange={this.handleChange}></input>
                    <label for="female">Female</label><br />

                    <select name="location" onChange={this.handleChange}>
                        <option value="Brooklyn">Brooklyn</option>
                        <option value="Manhattan">Manhattan</option>
                        <option value="Queens">Queens</option>
                        <option value="Staten Island">Staten Island</option>
                    </select><br />

                    <input type="checkbox" name="noMeat" value="noMeat" onChange={this.handleChange} />
                    <label for="noMeat">No Meat</label><br />
                    <input type="checkbox" name="noDairy" value="noDairy" onChange={this.handleChange} />
                    <label for="noDairy">No Dairy</label><br />
                    <input type="checkbox" name="noFish" value="noFish" onChange={this.handleChange} />
                    <label for="noFish">No Fish</label>
                </form>
                <button onClick={this.handleSubmit}>Submit!</button>
                <p style={{visibility:this.state.visibility}}>{this.state.firstName} {this.state.lastName} is {this.state.age} years old and is a {this.state.gender}. 
                They're going to {this.state.location} and have this diet: 
                {this.state.noMeat !=null?"No meat":null} {this.state.noDairy !=null?"No dairy":null} {this.state.noFish !=null?"No fish":null} <span style={{visibility:"hidden"}}>fdf</span></p>
                <hr />
            </div>
        )
    }
}

export default FormPractice