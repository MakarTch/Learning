import React from "react"
import ReactDOM from "react-dom"

class Forms extends React.Component{
    constructor(){
        super()
        this.state={
            firstName:"",
            lastName:""
        }
        this.handleChange = this.handleChange.bind(this)
    }

    handleChange(event){
        this.setState({
            [event.target.name] : event.target.value
        })
    }//watch out for errors on this, if theres some hard bug on thisgo to 3:48 of the tutorial

    render(){
        return(
            <div>
            <form>
                <input type="text" name="firstName" placeholder="First Name" autoComplete="off" onChange={this.handleChange}/>
                <input type="text" name="lastName" placeholder="Last Name" autoComplete="off" onChange={this.handleChange}/>
            </form>
            <h1>{this.state.firstName} {this.state.lastName}</h1>
            </div>
        )
        }
}

export default Forms
/*Formik is an api that helps you rwirte forms*/