import React from "react";
import ReactDOM from "react-dom";


function NavBar(){
    return(
        <header className="navbar">inside Navbar</header>
    )
};

export default NavBar;