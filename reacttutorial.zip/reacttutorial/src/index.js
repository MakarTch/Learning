import React from 'react';
import ReactDOM from 'react-dom';
import MyInfo from "./components/MyInfo";
import App from "./App";
import CheckList from "./components/CheckList";
import "./style.css"

// var element = React.createElement('h1', { className: 'greeting' }, 'Hello, world!');
// var element2 = React.createElement(<h1>Yoyo!</h1>, document.getElementById('root'));

let unorderedList = 
<ul>
  <li>Item 1</li>
  <li>Item 2</li>
  <li>Item 3</li>
</ul>;

ReactDOM.render(unorderedList, document.getElementById('root'));//using just a variable

function MyApp(){
  return (
  <ul>
    <li style={{color:"red"}}>Item 1</li>
    <li>Item 2</li>
    <li>Item 3</li>
  </ul>
)};//peep how i did inline styling there, gota make an object with an object, some shit like that

ReactDOM.render(<MyApp/>, document.getElementById("root2"));//using a function

ReactDOM.render(<MyInfo/>, document.getElementById("root3"));//using a function from another file, export it, import it up top on this file

ReactDOM.render(<App/>,document.getElementById("root4"));

ReactDOM.render(<CheckList/>,document.getElementById("root5"));

const date = new Date();
ReactDOM.render(<p>The time is {date.toLocaleTimeString()}.</p>, document.getElementById("root6"));