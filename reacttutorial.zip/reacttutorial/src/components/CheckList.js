import React from "react";
import ReactDOM from "react-dom";

function CheckList(){
    return(
        <div>
            <input type="checkbox"/>
            <span>Soup</span><br/>
            <input type="checkbox"/>
            <span>Chicken</span><br/>
            <input type="checkbox"/>
            <span>Broth</span><br/>
            <input type="checkbox"/>
            <span>Peas</span><br/>
        </div>
    )
}

export default CheckList;