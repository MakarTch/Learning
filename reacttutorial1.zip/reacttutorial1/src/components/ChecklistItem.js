import React from "react";
import ReactDOM from "react-dom";

function ChecklistItem(){
    return(
        <div>
            <input type="checkbox"/>
            <span>Item</span><br/>
        </div>
    )
};

export default ChecklistItem;